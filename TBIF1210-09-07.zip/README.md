# TugasBesarDasPro

<h2><center> Cara Untuk Menjalankan Program </center></h2>
<h4> Saat akan menjalankan program, tidak perlu menggunakan button 'run code' pada VS Code seperti yang dilakukan pada file python pada umumnya. Pada toolbar Visual Studio Code (pada bagian atas), ketik Terminal, lalu ketik New Terminal </h4>

<h4> Lalu masukkan input untuk memulai program dengan format sebagai berikut: </h4>
<h3><center> python (nama file python) (nama folder yang dibuka) </center></h3>
<h4> contoh : </h4>
<h3><center> python main.py main_save </center></h3>
<h4> Input seperti ini dilakukan sesuai dengan kebutuhan import argparse pada fungsi F15 Load. File python yang dijalankan adalah main.py karena file tersebut adalah file yang membaca input menggunakan argparse. Di sisi lain, main_save adalah salah satu folder dimana file csv disimpan. Nama folder tersebut dapat diganti bila ingin membaca file csv pada folder lainnya </h4>

<h2><center> Keterangan File dan Folder </center></h2>

<ul> 
<li> csv files </li>
<h4> Folder tersebut mengandung beberapa folder di dalamnya. Setiap folder dalam folder 'csv files' mengandung 4 csv files, yaitu 'user.csv', 'game.csv', 'riwayat.csv', dan 'kepemilikan.csv'. </h4>
<li> Testing Folder </li>
<h4> Folder tersebut berisi 2 files yaitu 'test.py' dan 'test.csv'. Kedua file ini digunakan untuk melakukan pengecekan algoritma sebelum dimasukan ke dalam program utama. </h4>
<li> main.py </li>
<h4> Berisi program dan algoritma program utama </h4>
<li> F2_F7.py </li>
<h4> Berisi program dan algoritma subprograms. Fungsi-fungsi tersebut terdiri dari F2 hingga F7 </h4>
<li> F8_F13.py </li>
<h4> Berisi program dan algoritma subprograms. Fungsi-fungsi tersebut terdiri dari F8 hingga F13 </h4>
<li> F14_F17.py </li>
<h4> Berisi program dan algoritma subprograms. Fungsi-fungsi tersebut terdiri dari F14 hingga F17 serta beberapa fungsi tambahan </h4>
<li> csvlistfunction.py </li>
<h4> Berisi program dan algoritma program untuk mengolah list dan csv. </h4>
<li> password.py </li>
<h4> Berisi program dan algoritma program untuk menyelesaikan permasalahan bonus 1 yaitu chippered passwords. </h4>
<li> kerangajaib.py </li>
<h4> Berisi program dan alogritma program untuk menyelesaikan permasalahan bonus 2 yaitu pertanyaan kepada kerang ajaib. </h4>
<li> tictactoe.py </li>
<h4> Berisi program dan algoritma program untuk menyelesaikan permasalahan bonus 3 yaitu menjalankan permaiann tic-tac-toe. </h4>

</ul>
